/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 pinkBlk pinkBlk.png
 * Time-stamp: Thursday 04/11/2019, 14:42:09
 *
 * Image Information
 * -----------------
 * pinkBlk.png 6@6
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PINKBLK_H
#define PINKBLK_H

extern unsigned short pinkBlk[36];
#define PINKBLK_SIZE 72
#define PINKBLK_LENGTH 36
#define PINKBLK_WIDTH 6
#define PINKBLK_HEIGHT 6

#endif

