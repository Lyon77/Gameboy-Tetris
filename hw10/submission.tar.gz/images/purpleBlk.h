/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 purpleBlk purpleBlk.png
 * Time-stamp: Friday 04/12/2019, 01:13:23
 *
 * Image Information
 * -----------------
 * purpleBlk.png 6@6
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PURPLEBLK_H
#define PURPLEBLK_H

extern unsigned short purpleBlk[36];
#define PURPLEBLK_SIZE 72
#define PURPLEBLK_LENGTH 36
#define PURPLEBLK_WIDTH 6
#define PURPLEBLK_HEIGHT 6

#endif

