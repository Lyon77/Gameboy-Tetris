/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 greenBlk greenBlk.png
 * Time-stamp: Thursday 04/11/2019, 14:41:58
 *
 * Image Information
 * -----------------
 * greenBlk.png 6@6
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GREENBLK_H
#define GREENBLK_H

extern unsigned short greenBlk[36];
#define GREENBLK_SIZE 72
#define GREENBLK_LENGTH 36
#define GREENBLK_WIDTH 6
#define GREENBLK_HEIGHT 6

#endif

