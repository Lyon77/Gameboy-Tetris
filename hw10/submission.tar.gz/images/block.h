/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block block.png
 * Time-stamp: Monday 04/08/2019, 19:21:23
 *
 * Image Information
 * -----------------
 * block.png 6@6
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_H
#define BLOCK_H

extern unsigned short block[36];
#define BLOCK_SIZE 72
#define BLOCK_LENGTH 36
#define BLOCK_WIDTH 6
#define BLOCK_HEIGHT 6

#endif

