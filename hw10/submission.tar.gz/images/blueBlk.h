/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 blueBlk blueBlk.png
 * Time-stamp: Thursday 04/11/2019, 14:41:46
 *
 * Image Information
 * -----------------
 * blueBlk.png 6@6
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLUEBLK_H
#define BLUEBLK_H

extern unsigned short blueBlk[36];
#define BLUEBLK_SIZE 72
#define BLUEBLK_LENGTH 36
#define BLUEBLK_WIDTH 6
#define BLUEBLK_HEIGHT 6

#endif

