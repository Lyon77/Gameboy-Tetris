/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 main pixil-frame-0.png
 * Time-stamp: Saturday 04/06/2019, 18:15:55
 *
 * Image Information
 * -----------------
 * pixil-frame-0.png 240@160
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MAIN_H
#define MAIN_H

extern const unsigned short tetrisMain[38400];
#define PIXILFRAME0_SIZE 76800
#define PIXILFRAME0_LENGTH 38400
#define PIXILFRAME0_WIDTH 240
#define PIXILFRAME0_HEIGHT 160

#endif

