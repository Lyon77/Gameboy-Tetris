/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 orangeBlk orangeBlk.png
 * Time-stamp: Thursday 04/11/2019, 14:41:33
 *
 * Image Information
 * -----------------
 * orangeBlk.png 6@6
 *
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ORANGEBLK_H
#define ORANGEBLK_H

extern unsigned short orangeBlk[36];
#define ORANGEBLK_SIZE 72
#define ORANGEBLK_LENGTH 36
#define ORANGEBLK_WIDTH 6
#define ORANGEBLK_HEIGHT 6

#endif

