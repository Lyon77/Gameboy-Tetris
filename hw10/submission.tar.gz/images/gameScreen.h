/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 gameScreen gameScreen.png 
 * Time-stamp: Friday 04/12/2019, 01:17:50
 * 
 * Image Information
 * -----------------
 * gameScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMESCREEN_H
#define GAMESCREEN_H

extern const unsigned short gameScreen[38400];
#define GAMESCREEN_SIZE 76800
#define GAMESCREEN_LENGTH 38400
#define GAMESCREEN_WIDTH 240
#define GAMESCREEN_HEIGHT 160

#endif

