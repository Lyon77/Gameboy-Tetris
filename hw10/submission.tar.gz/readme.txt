Hi!

---Welcome to my implementation of Tetris---

In tetris, the goal is to fill in lines. In my implementation, every row completed scores you one point. You have control of the piece on the board, but watch out, the block slowly moves down on it's own. You can see the next block coming up in the top left box and the saved block in the box right below it. You can switch your current block with the saved block. Have Fun!

--Starting Screen--
Start/Enter - begin the game

--Game Screen--
Left - moves the block left
Right - moves the block right
Down - brings the block down as far as it can go
A/Z - spins the block clockwise
B/X - spins the block counterclockwise
L/A - switches the block with the saved block (the bottom block on the left hand side)
Select/BackSpace - brings you back to Starting Screen

--End Screen--
Start/Enter - brings you back to Starting Screen
Select/BackSpace - brings you back to Starting Screen


I hope you enjoy it :)


-Ryan Li